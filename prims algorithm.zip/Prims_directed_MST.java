package assignment1;

import java.util.Scanner;
public class Prims_directed_MST {
	
	private static Scanner scan;
	public static void main(String args[])
	{
 scan = new Scanner(System.in);
 int[][] adjacent_matrix=new int[11][11];
 //we are taking 10 nodes
 int[] visited=new int[11];
 //to keep track of visited nodes
 int minimum;
 int u=0;
 int v=0;
 int total_distance = 0;
 
 for(int i=0;i<11;i++)
 {
    visited[i]=0;
	 for(int j=0;j<11;j++)
	 {
		 adjacent_matrix[i][j]=scan.nextInt();
		 if(adjacent_matrix[i][j]==0 || adjacent_matrix[i][j]<0 )
			 adjacent_matrix[i][j]=999;
	 }
	 
 }
 System.out.print("adjacency matrix of directed graph is \n ");
 for(int i=0;i<11;i++)
 {
	 for(int j=0;j<11;j++)
	 {
		 System.out.print(adjacent_matrix[i][j] + "\t");
	 }
	 System.out.print("\n");
}

 
 
 
      visited[7]=1;
 
 
     
	
	 
   	  //start of prims algorithm
     for(int counter=0;counter<10;counter++)
     {
   	  minimum=999;
   	  for(int i=0;i<11;i++)
   	  {
   	    if( visited[i]==1)
   	    {
   	        for(int j=0;j<11;j++)
   	       {
   		      if(visited[j]!=1)
   		       {
   			      if(minimum>adjacent_matrix[i][j])
   			      {
   			    	  minimum=adjacent_matrix[i][j];
   			    	  u=i;
   			    	  v=j;
   			      }
   		       }
   	        } 
   	    }   
       }
     
   	  visited[v]=1;
   	  total_distance+=minimum;
   	  
   	  System.out.println(" directed edge found from " + u +"-> to " + v + " weight" +  minimum);
	}
     System.out.println("the total weight of minimum spanning tree of directed graph is" + total_distance);
     

	}
}
